# Getting real "Add to Home Screen" working

Chrome only shows the install prompt for pages served over https with a
manifest + service worker — never for files opened straight off your phone
(file://). This folder has everything needed; you just need to host it.

Easiest free option: **GitHub Pages**, using your existing account (1lester).

## Steps

1. Go to https://github.com/new and create a new repo, e.g. `khata`.
   Keep it public (required for free GitHub Pages).

2. Upload these 5 files into that repo (drag-and-drop on the GitHub
   web UI works fine — "Add file" → "Upload files"):
   - index.html
   - manifest.json
   - sw.js
   - icon-192.png
   - icon-512.png

3. Go to the repo's **Settings → Pages**. Under "Build and deployment",
   set Source = "Deploy from a branch", Branch = "main", folder = "/ (root)".
   Save.

4. Wait ~1 minute. Your app will be live at:
   `https://1lester.github.io/khata/`

5. Open that link in Chrome on your phone. Now the **⋮ menu → "Add to
   Home screen" / "Install app"** option will actually appear, because
   the page is served over https with a manifest and service worker.

That's it — after this, Khata behaves like a real installed app icon,
opens full-screen, and still keeps all your data private to your device
(nothing is sent to any server; GitHub Pages is just hosting the static
files, not storing your expenses).
